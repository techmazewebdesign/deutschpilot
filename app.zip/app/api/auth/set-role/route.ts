import { NextRequest, NextResponse } from "next/server";
import { getAdminAuth, getAdminDb } from "@/lib/firebase-admin";

const isDev = process.env.NODE_ENV === "development";
const ALLOWED_SIGNUP_ROLES = ["student", "teacher"] as const;
type SignupRole = (typeof ALLOWED_SIGNUP_ROLES)[number];

export async function POST(req: NextRequest) {
  let uid = "";
  let safeRole: SignupRole = "student";

  try {
    const body = await req.json();
    const { idToken, fullName, email, role, germanLevel } = body;

    if (!idToken || !fullName) {
      console.error("[set-role] Missing required fields:", { hasIdToken: !!idToken, hasFullName: !!fullName });
      return NextResponse.json({ error: "Missing required fields." }, { status: 400 });
    }

    safeRole = ALLOWED_SIGNUP_ROLES.includes(role) ? role : "student";

    // Step 1: Verify the Firebase ID token
    let decoded;
    try {
      console.log("[set-role] Verifying ID token...");
      decoded = await getAdminAuth().verifyIdToken(idToken);
      uid = decoded.uid;
      console.log("[set-role] Token verified, uid:", uid);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      console.error("[set-role] verifyIdToken failed:", msg);
      return NextResponse.json(
        { error: "Invalid ID token.", ...(isDev && { detail: msg }) },
        { status: 401 }
      );
    }

    const userEmail = email ?? decoded.email ?? "";

    // Step 2: Set custom claims (non-blocking — warn on failure, don't abort)
    try {
      console.log("[set-role] Setting custom claims...");
      await getAdminAuth().setCustomUserClaims(uid, { role: safeRole });
      console.log("[set-role] Custom claims set:", safeRole);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      console.warn("[set-role] setCustomUserClaims failed (non-blocking):", msg);
    }

    // Step 3: Save profile to Firestore
    try {
      console.log("[set-role] Saving profile to Firestore...");
      await getAdminDb()
        .doc(`users/${uid}`)
        .set(
          {
            uid,
            fullName,
            email: userEmail,
            role: safeRole,
            germanLevel: germanLevel ?? null,
            createdAt: new Date(),
            emailVerified: false,
            disabled: false,
          },
          { merge: true }
        );
      console.log("[set-role] Firestore profile saved for uid:", uid);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      console.error("[set-role] Firestore save failed:", msg);
      return NextResponse.json(
        { error: "Profile save failed.", ...(isDev && { detail: msg }) },
        { status: 500 }
      );
    }

    console.log("[set-role] Complete. uid:", uid, "role:", safeRole);
    return NextResponse.json({ ok: true, uid, role: safeRole });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error("[set-role] Unexpected error:", msg);
    return NextResponse.json(
      { error: "Failed to set user role.", ...(isDev && { detail: msg }) },
      { status: 500 }
    );
  }
}
