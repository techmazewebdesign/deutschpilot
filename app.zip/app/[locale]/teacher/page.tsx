import { redirect } from "next/navigation";
import Link from "next/link";
import { getServerSession } from "@/lib/session";
import { AppLayout } from "@/components/app/app-layout";
import {
  GraduationCap,
  Users,
  BookOpen,
  BarChart2,
  MessageSquare,
  PlusCircle,
  ArrowRight,
  Clock,
  CheckCircle2,
} from "lucide-react";

export const dynamic = "force-dynamic";

export default async function TeacherPage({ params }: { params: { locale: string } }) {
  const { locale } = params;
  const de = locale === "de";

  const session = await getServerSession();
  if (!session) redirect(`/${locale}/signin`);

  // Students who somehow land here get redirected to their own page
  if (session.user.role === "student") redirect(`/${locale}/rooms`);

  const userName = session.user.name ?? session.user.email?.split("@")[0] ?? "Teacher";

  const cards = [
    {
      icon: Users,
      titleDE: "Meine Klassen",
      titleEN: "My Classes",
      valueDE: "3 aktive Klassen",
      valueEN: "3 active classes",
      accent: "#E0B873",
      href: null,
    },
    {
      icon: GraduationCap,
      titleDE: "Meine Schüler",
      titleEN: "My Students",
      valueDE: "24 Schüler",
      valueEN: "24 students",
      accent: "#E0B873",
      href: null,
    },
    {
      icon: BookOpen,
      titleDE: "Verwaltete Lektionen",
      titleEN: "Managed Lessons",
      valueDE: "12 Lektionen",
      valueEN: "12 lessons",
      accent: "#E0B873",
      href: `/${locale}/rooms`,
    },
    {
      icon: BarChart2,
      titleDE: "Schülerfortschritt",
      titleEN: "Student Progress",
      valueDE: "Ø 68% Abschluss",
      valueEN: "Avg. 68% completion",
      accent: "#E0B873",
      href: null,
    },
    {
      icon: MessageSquare,
      titleDE: "Nachrichten",
      titleEN: "Messages",
      valueDE: "2 ungelesen",
      valueEN: "2 unread",
      accent: "#E0B873",
      href: null,
    },
    {
      icon: PlusCircle,
      titleDE: "Lektion erstellen",
      titleEN: "Create Lesson",
      valueDE: "Neue Lektion anlegen",
      valueEN: "Add a new lesson",
      accent: "#E0B873",
      href: `/${locale}/rooms`,
    },
  ];

  const recentActivity = [
    {
      labelDE: "Anna K. hat Raum 1 abgeschlossen",
      labelEN: "Anna K. completed Room 1",
      timeDE: "vor 2 Std.",
      timeEN: "2 hrs ago",
      done: true,
    },
    {
      labelDE: "Max M. hat eine Frage gestellt",
      labelEN: "Max M. asked a question",
      timeDE: "vor 4 Std.",
      timeEN: "4 hrs ago",
      done: false,
    },
    {
      labelDE: "Sara L. hat Checkpoint-Quiz bestanden",
      labelEN: "Sara L. passed Checkpoint Quiz",
      timeDE: "gestern",
      timeEN: "yesterday",
      done: true,
    },
    {
      labelDE: "Lektion A1.3 wurde aktualisiert",
      labelEN: "Lesson A1.3 was updated",
      timeDE: "gestern",
      timeEN: "yesterday",
      done: true,
    },
  ];

  return (
    <AppLayout locale={locale} userName={userName} userLevel="Lehrer">
      <div className="px-5 lg:px-8 py-6 lg:py-8 max-w-5xl w-full mx-auto space-y-8">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <GraduationCap className="h-4 w-4 text-[#E0B873]" />
              <span className="text-xs font-semibold text-[#E0B873]/70 uppercase tracking-[0.2em]">
                {de ? "Lehrer-Dashboard" : "Teacher Dashboard"}
              </span>
            </div>
            <h1 className="text-3xl font-serif font-bold text-white mb-1">
              {de ? `Willkommen, ${userName}` : `Welcome, ${userName}`}
            </h1>
            <p className="text-sm text-white/40">
              {de
                ? "Hier verwaltest du deine Klassen, Schüler und Lektionen."
                : "Manage your classes, students, and lessons here."}
            </p>
          </div>
        </div>

        {/* Cards grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {cards.map((card) => {
            const Icon = card.icon;
            const inner = (
              <div className="p-5 flex flex-col gap-3 h-full">
                <div className="h-10 w-10 rounded-xl bg-[#E0B873]/10 border border-[#E0B873]/20 flex items-center justify-center">
                  <Icon className="h-5 w-5 text-[#E0B873]" />
                </div>
                <div className="flex-1">
                  <p className="text-xs text-white/40 uppercase tracking-wider mb-1">
                    {de ? card.titleDE : card.titleEN}
                  </p>
                  <p className="text-lg font-semibold text-white leading-tight">
                    {de ? card.valueDE : card.valueEN}
                  </p>
                </div>
                {card.href && (
                  <div className="flex items-center gap-1 text-xs text-[#E0B873]/60 group-hover:text-[#E0B873] transition-colors">
                    {de ? "Öffnen" : "Open"}
                    <ArrowRight className="h-3 w-3" />
                  </div>
                )}
              </div>
            );

            const cls =
              "group relative overflow-hidden rounded-2xl border border-white/8 bg-[#0A1E35]/70 backdrop-blur-sm hover:border-[#E0B873]/20 transition-all flex flex-col";

            return card.href ? (
              <Link key={card.titleEN} href={card.href} className={cls}>
                {inner}
              </Link>
            ) : (
              <div key={card.titleEN} className={cls}>
                {inner}
              </div>
            );
          })}
        </div>

        {/* Recent activity */}
        <section>
          <div className="flex items-center gap-2 mb-4">
            <Clock className="h-4 w-4 text-[#E0B873]" />
            <h2 className="text-sm font-semibold text-white">
              {de ? "Letzte Aktivitäten" : "Recent Activity"}
            </h2>
          </div>
          <div className="rounded-2xl border border-white/8 bg-[#0A1E35]/50 overflow-hidden">
            {recentActivity.map((item, i) => (
              <div
                key={i}
                className={`flex items-center justify-between px-5 py-4 ${
                  i < recentActivity.length - 1 ? "border-b border-white/5" : ""
                }`}
              >
                <div className="flex items-center gap-3">
                  {item.done ? (
                    <CheckCircle2 className="h-4 w-4 text-[#E0B873]/60 flex-shrink-0" />
                  ) : (
                    <MessageSquare className="h-4 w-4 text-white/30 flex-shrink-0" />
                  )}
                  <p className="text-sm text-white/70">
                    {de ? item.labelDE : item.labelEN}
                  </p>
                </div>
                <span className="text-xs text-white/30 flex-shrink-0 ml-4">
                  {de ? item.timeDE : item.timeEN}
                </span>
              </div>
            ))}
          </div>
        </section>

        {/* Quick links */}
        <section className="bg-[#0A1E35]/50 border border-white/6 rounded-xl p-5">
          <h3 className="text-sm font-semibold text-white mb-3">
            {de ? "Schnellzugriff" : "Quick Links"}
          </h3>
          <div className="flex flex-wrap gap-3">
            <Link
              href={`/${locale}/rooms`}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#E0B873]/10 border border-[#E0B873]/20 text-[#E0B873] text-xs font-semibold hover:bg-[#E0B873]/20 transition-colors"
            >
              <BookOpen className="h-3.5 w-3.5" />
              {de ? "Lernräume ansehen" : "View Learning Rooms"}
            </Link>
            <Link
              href={`/${locale}/ai-trainer`}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-white/60 text-xs font-semibold hover:bg-white/8 hover:text-white transition-colors"
            >
              <MessageSquare className="h-3.5 w-3.5" />
              {de ? "KI-Trainer" : "AI Trainer"}
            </Link>
          </div>
        </section>

        {/* Note */}
        <p className="text-xs text-white/20 text-center pb-2">
          {de
            ? "Vollständige Lehrerverwaltung ist in Kürze verfügbar."
            : "Full teacher management features coming soon."}
        </p>

      </div>
    </AppLayout>
  );
}
