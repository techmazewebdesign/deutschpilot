import { redirect } from "next/navigation";
import Link from "next/link";
import { getServerSession } from "@/lib/session";
import { getAdminDb } from "@/lib/firebase-admin";
import { AppLayout } from "@/components/app/app-layout";
import { UsersTable } from "@/components/admin/users-table";
import { Shield, Users, ArrowLeft } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function AdminPage({ params }: { params: { locale: string } }) {
  const { locale } = params;

  const session = await getServerSession();
  if (!session) redirect(`/${locale}/signin`);
  if (session.user.role === "teacher") redirect(`/${locale}/teacher`);
  if (session.user.role !== "admin") redirect(`/${locale}/rooms`);

  const de = locale === "de";

  let totalCourses = 0;
  try {
    const snap = await getAdminDb().collection("users").count().get();
    totalCourses = snap.data().count;
  } catch {
    /* Firestore may not have count API on all plans */
  }

  return (
    <AppLayout locale={locale} userName={session.user.name} userLevel="admin">
      <div className="px-5 lg:px-8 py-6 lg:py-8 max-w-6xl w-full mx-auto space-y-8">

        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-red-400/10 border border-red-400/20 flex items-center justify-center">
              <Shield className="h-5 w-5 text-red-400" />
            </div>
            <div>
              <h1 className="text-2xl font-serif font-bold text-white">
                {de ? "Admin-Dashboard" : "Admin Dashboard"}
              </h1>
              <p className="text-xs text-white/40">
                {de ? "Vollständige Kontrolle über Benutzer und Inhalte" : "Complete control over users and content"}
              </p>
            </div>
          </div>
          <Link
            href={`/${locale}/dashboard`}
            className="flex items-center gap-2 text-xs text-white/40 hover:text-white/70 transition-colors"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            {de ? "Zurück zum Dashboard" : "Back to dashboard"}
          </Link>
        </div>

        {/* Users section */}
        <section>
          <div className="flex items-center gap-2 mb-5">
            <Users className="h-4 w-4 text-[#E0B873]" />
            <h2 className="text-base font-semibold text-white">
              {de ? "Benutzerverwaltung" : "User Management"}
            </h2>
          </div>
          <UsersTable locale={locale} currentUserId={session.user.id} />
        </section>

        {/* Instructions */}
        <section className="bg-[#0A1E35]/50 border border-white/6 rounded-xl p-5">
          <h3 className="text-sm font-semibold text-white mb-3">
            {de ? "Hinweise" : "Notes"}
          </h3>
          <ul className="space-y-1.5 text-xs text-white/45">
            <li>• {de ? "Rollenänderungen werden sofort gespeichert. Der Benutzer muss sich erneut anmelden, damit die neue Rolle wirksam wird." : "Role changes are saved immediately. The user must sign in again for the new role to take effect."}</li>
            <li>• {de ? "Deaktivierte Benutzer können sich nicht mehr anmelden." : "Disabled users cannot sign in."}</li>
            <li>• {de ? "Gelöschte Benutzer können nicht wiederhergestellt werden." : "Deleted users cannot be recovered."}</li>
            <li>• {de ? "Dein eigenes Konto kann nicht geändert werden." : "Your own account cannot be modified."}</li>
          </ul>
        </section>

      </div>
    </AppLayout>
  );
}
