import { redirect } from "next/navigation";
import Link from "next/link";
import { AppLayout } from "@/components/app/app-layout";
import { auth } from "@/lib/auth";
import { isPlaceholderLocale } from "@/i18n";
import { Navigation } from "@/components/navigation";
import { PlaceholderPage } from "@/components/placeholder-page";
import { Footer } from "@/components/footer";
import {
  Lock, ChevronRight, BookOpen, Users, Globe, ShoppingBag,
  MapPin, Stethoscope, Clock, CheckCircle2,
} from "lucide-react";

export const dynamic = "force-dynamic";

const ROOMS = [
  {
    id: 1, slug: "greetings",
    icon: Users,
    titleDE: "Begrüßungen & Vorstellungen",
    titleEN: "Greetings & Introductions",
    lessons: 5,
    descDE: "Erste Kontakte knüpfen, sich vorstellen, grüßen.",
    descEN: "Make first contacts, introduce yourself, greet others.",
    unlocked: true,
    checkpointDE: "A1.1 – Bestanden",
    checkpointEN: "A1.1 – Passed",
    progress: 0,
  },
  {
    id: 2, slug: "numbers-time",
    icon: Clock,
    titleDE: "Zahlen, Zeit & Datum",
    titleEN: "Numbers, Time & Dates",
    lessons: 5,
    descDE: "Zahlen, Uhrzeit, Datum und Wochentage auf Deutsch.",
    descEN: "Numbers, clock time, dates, and days of the week.",
    unlocked: true,
    checkpointDE: "A1.2 – Checkpoint",
    checkpointEN: "A1.2 – Checkpoint",
    progress: 0,
  },
  {
    id: 3, slug: "family-life",
    icon: Users,
    titleDE: "Familie & Persönliches Leben",
    titleEN: "Family & Personal Life",
    lessons: 8,
    descDE: "Familie beschreiben, Hobbys und persönliche Informationen teilen.",
    descEN: "Describe family, share hobbies and personal information.",
    unlocked: false,
    checkpointDE: "A1.3 – Gesperrt",
    checkpointEN: "A1.3 – Locked",
    progress: 0,
  },
  {
    id: 4, slug: "shopping",
    icon: ShoppingBag,
    titleDE: "Einkaufen & Alltag",
    titleEN: "Shopping & Daily Needs",
    lessons: 7,
    descDE: "Im Supermarkt, Preise verstehen, nach Produkten fragen.",
    descEN: "At the supermarket, understand prices, ask for products.",
    unlocked: false,
    checkpointDE: "A1.4 – Gesperrt",
    checkpointEN: "A1.4 – Locked",
    progress: 0,
  },
  {
    id: 5, slug: "city-transport",
    icon: MapPin,
    titleDE: "Stadt, Transport & Wegbeschreibung",
    titleEN: "City, Transport & Directions",
    lessons: 8,
    descDE: "Sich in der Stadt zurechtfinden, öffentliche Verkehrsmittel nutzen.",
    descEN: "Navigate the city, use public transport, ask for directions.",
    unlocked: false,
    checkpointDE: "A1.5 – Gesperrt",
    checkpointEN: "A1.5 – Locked",
    progress: 0,
  },
  {
    id: 6, slug: "real-life",
    icon: Stethoscope,
    titleDE: "Arzt, Büro & Alltag",
    titleEN: "Doctor, Office & Real Life",
    lessons: 8,
    descDE: "Beim Arzt, im Büro und in alltäglichen Situationen kommunizieren.",
    descEN: "Communicate at the doctor, office and everyday situations.",
    unlocked: false,
    checkpointDE: "A1.6 – Gesperrt",
    checkpointEN: "A1.6 – Locked",
    progress: 0,
  },
];

export default async function RoomsPage({ params }: { params: { locale: string } }) {
  const { locale } = params;

  if (isPlaceholderLocale(locale)) {
    return (
      <>
        <Navigation />
        <PlaceholderPage locale={locale} />
        <Footer />
      </>
    );
  }

  const session = await auth();
  if (!session?.user) redirect(`/${locale}/signin`);

  const de = locale === "de";
  const userName = session.user.name ?? session.user.email?.split("@")[0] ?? "Student";

  return (
    <AppLayout locale={locale} userName={userName}>
      <div className="px-5 lg:px-8 py-6 lg:py-8 max-w-5xl w-full mx-auto">

        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-2">
            <Globe className="h-4 w-4 text-[#E0B873]" />
            <span className="text-xs font-semibold text-[#E0B873]/70 uppercase tracking-[0.2em]">A1</span>
          </div>
          <h1 className="text-3xl font-serif font-bold text-white mb-2">
            {de ? "Lernräume" : "Learning Rooms"}
          </h1>
          <p className="text-sm text-white/45 max-w-xl">
            {de
              ? "Jeder Raum ist ein Themenbereich mit Lektionen, Übungen und einem Checkpoint-Quiz."
              : "Each room is a topic area with lessons, exercises, and a checkpoint quiz."}
          </p>
        </div>

        {/* Level selector strip */}
        <div className="flex items-center gap-2 mb-8 overflow-x-auto pb-1">
          {["A1", "A2", "B1", "B2", "C1"].map((lvl, i) => (
            <div key={lvl} className={`flex-shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              lvl === "A1"
                ? "bg-[#E0B873]/15 text-[#E0B873] border border-[#E0B873]/30"
                : i <= 1
                ? "text-white/40 border border-white/10 hover:border-white/20 cursor-pointer"
                : "text-white/20 border border-white/6 cursor-not-allowed"
            }`}>
              {lvl}
              {i > 1 && <Lock className="h-2.5 w-2.5" />}
            </div>
          ))}
        </div>

        {/* Rooms grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {ROOMS.map((room) => {
            const Icon = room.icon;
            return (
              <div key={room.id}
                className={`relative overflow-hidden rounded-2xl border transition-all flex flex-col ${
                  room.unlocked
                    ? "border-white/10 bg-[#0A1E35]/70 backdrop-blur-sm hover:border-[#E0B873]/25"
                    : "border-white/6 bg-[#0A1E35]/30 opacity-55"
                }`}>
                {/* Room number tag */}
                <div className="absolute top-4 right-4">
                  <span className="text-[9px] font-bold text-white/20 bg-white/5 px-1.5 py-0.5 rounded">
                    {de ? `Raum ${room.id}` : `Room ${room.id}`}
                  </span>
                </div>

                <div className="p-5 flex-1 flex flex-col">
                  {/* Icon */}
                  <div className={`h-11 w-11 rounded-xl flex items-center justify-center mb-4 ${
                    room.unlocked
                      ? "bg-[#E0B873]/12 border border-[#E0B873]/20"
                      : "bg-white/5 border border-white/8"
                  }`}>
                    {room.unlocked
                      ? <Icon className="h-5 w-5 text-[#E0B873]" />
                      : <Lock className="h-5 w-5 text-white/25" />
                    }
                  </div>

                  <h3 className={`font-semibold text-sm leading-snug mb-1.5 ${room.unlocked ? "text-white" : "text-white/35"}`}>
                    {de ? room.titleDE : room.titleEN}
                  </h3>
                  <p className="text-xs text-white/35 leading-relaxed flex-1 mb-4">
                    {de ? room.descDE : room.descEN}
                  </p>

                  {/* Meta */}
                  <div className="flex items-center gap-3 mb-3">
                    <div className="flex items-center gap-1 text-xs text-white/35">
                      <BookOpen className="h-3 w-3" />
                      <span>{room.lessons} {de ? "Lektionen" : "lessons"}</span>
                    </div>
                    <div className="flex items-center gap-1 text-xs">
                      {room.unlocked
                        ? <CheckCircle2 className="h-3 w-3 text-[#E0B873]/60" />
                        : <Lock className="h-3 w-3 text-white/20" />
                      }
                      <span className={`text-xs ${room.unlocked ? "text-[#E0B873]/60" : "text-white/20"}`}>
                        {de ? room.checkpointDE : room.checkpointEN}
                      </span>
                    </div>
                  </div>

                  {/* Progress bar */}
                  <div className="mb-4">
                    <div className="flex items-center justify-between text-[10px] text-white/30 mb-1.5">
                      <span>{de ? "Fortschritt" : "Progress"}</span>
                      <span>{room.progress}%</span>
                    </div>
                    <div className="h-1 bg-white/6 rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-[#E0B873] to-[#C99B50] rounded-full transition-all"
                        style={{ width: `${room.progress}%` }} />
                    </div>
                  </div>

                  {/* CTA */}
                  {room.unlocked ? (
                    <Link href={`/${locale}/rooms/${room.slug}`}
                      className="flex items-center justify-center gap-1.5 w-full py-2.5 rounded-xl bg-[#E0B873]/10 border border-[#E0B873]/20 text-[#E0B873] text-xs font-semibold hover:bg-[#E0B873]/20 transition-colors">
                      {de ? "Raum betreten" : "Enter Room"} <ChevronRight className="h-3.5 w-3.5" />
                    </Link>
                  ) : (
                    <div className="flex items-center justify-center gap-1.5 w-full py-2.5 rounded-xl bg-white/3 border border-white/8 text-white/25 text-xs font-medium">
                      <Lock className="h-3.5 w-3.5" />
                      {de ? "Gesperrt" : "Locked"}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Unlock hint */}
        <div className="mt-6 p-4 rounded-2xl bg-white/3 border border-white/6 flex items-start gap-3">
          <Lock className="h-4 w-4 text-white/30 flex-shrink-0 mt-0.5" />
          <p className="text-xs text-white/35">
            {de
              ? "Abgesperrte Räume werden freigeschaltet, wenn du den vorherigen Raum mit mindestens 60% beim Checkpoint-Quiz abschließt."
              : "Locked rooms unlock when you complete the previous room's checkpoint quiz with at least 60%."}
          </p>
        </div>
      </div>
    </AppLayout>
  );
}
