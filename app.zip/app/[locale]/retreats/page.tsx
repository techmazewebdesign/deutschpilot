import { getTranslations } from "next-intl/server";
import Link from "next/link";
import { Navigation } from "@/components/navigation";
import { Footer } from "@/components/footer";
import { PlaceholderPage } from "@/components/placeholder-page";
import { isPlaceholderLocale } from "@/i18n";

export default async function RetreatsPage({ params }: { params: { locale: string } }) {
  const { locale } = params;

  if (isPlaceholderLocale(locale)) {
    return (
      <>
        <Navigation />
        <PlaceholderPage locale={locale} />
        <Footer />
      </>
    );
  }

  const t = await getTranslations({ locale, namespace: "retreats" });

  return (
    <>
      <Navigation />
      <main className="min-h-screen bg-[#071424]">
        <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
          <div className="text-center mb-14">
            <p className="text-xs font-medium tracking-wider text-[#CEA66F] uppercase mb-3">{t("subtitle")}</p>
            <h1 className="text-4xl sm:text-5xl font-serif font-bold text-white mb-6">{t("title")}</h1>
          </div>

          <div className="grid sm:grid-cols-2 gap-5 mb-12">
            {[
              { key: "duration", icon: "📅" },
              { key: "accommodation", icon: "🏡" },
              { key: "activities", icon: "🌿" },
              { key: "networking", icon: "🤝" },
            ].map((item) => (
              <div key={item.key} className="flex items-center gap-4 bg-[#0B1B33]/50 border border-white/10 rounded-xl p-5">
                <span className="text-2xl">{item.icon}</span>
                <span className="text-[#C9D2DE]">{t(`features.${item.key}`)}</span>
              </div>
            ))}
          </div>

          <div className="text-center">
            <Link href={`/${locale}/signup`} className="inline-block bg-[#D9B173] text-[#071424] font-semibold px-8 py-3 rounded-md hover:bg-[#B98A4E] transition-colors">
              {t("cta")}
            </Link>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
