import { redirect } from "next/navigation";
import Link from "next/link";
import { Navigation } from "@/components/navigation";
import { Footer } from "@/components/footer";
import { PlaceholderPage } from "@/components/placeholder-page";
import { AppLayout } from "@/components/app/app-layout";
import { auth } from "@/lib/auth";
import { createServerSupabaseClient } from "@/lib/supabaseServer";
import { isPlaceholderLocale } from "@/i18n";
import {
  BookOpen, Play, FlaskConical, Flame, MessageSquare,
  Trophy, TrendingUp, BookMarked, ChevronRight, Zap,
  CheckCircle2, Circle,
} from "lucide-react";

export const dynamic = "force-dynamic";

export default async function DashboardPage({ params }: { params: { locale: string } }) {
  const { locale } = params;

  if (isPlaceholderLocale(locale)) {
    return (
      <>
        <Navigation />
        <PlaceholderPage locale={locale} />
        <Footer />
      </>
    );
  }

  const session = await auth();
  if (!session?.user) redirect(`/${locale}/signin`);

  const supabase = createServerSupabaseClient();

  // ── Parallel data fetching ─────────────────────────────────
  const [profileRes, progressRes, placementRes] = await Promise.all([
    supabase.from("profiles").select("full_name, german_level, learning_goal").eq("id", session.user.id).single(),
    supabase.from("student_progress").select("lesson_id, course_id, completed, updated_at").eq("user_id", session.user.id).order("updated_at", { ascending: false }),
    supabase.from("placement_tests").select("level_result, score, created_at").eq("user_id", session.user.id).order("created_at", { ascending: false }).limit(1),
  ]);

  const profile = profileRes.data;
  const progressRows = progressRes.data ?? [];
  const latestPlacement = placementRes.data?.[0] ?? null;

  // Derived stats
  const completedLessons = progressRows.filter((p) => p.completed).length;
  const displayLevel = latestPlacement?.level_result || profile?.german_level || "A1";
  const userName = profile?.full_name || session.user.email?.split("@")[0] || "Student";

  // Current course: most recently active
  const latestProgress = progressRows[0];
  let currentCourse: { id: string; title: string; slug: string } | null = null;
  let nextLesson: { title: string; slug: string } | null = null;
  let courseProgress = 0;
  let totalLessonsInCourse = 0;
  let completedInCourse = 0;

  if (latestProgress?.course_id) {
    const [courseRes, allLessonsRes] = await Promise.all([
      supabase.from("courses").select("id, title, slug").eq("id", latestProgress.course_id).single(),
      supabase.from("lessons").select("id, title, slug, order_index").eq("course_id", latestProgress.course_id).lt("order_index", 99).order("order_index"),
    ]);
    currentCourse = courseRes.data;
    const allLessons = allLessonsRes.data ?? [];
    totalLessonsInCourse = allLessons.length;
    const completedIds = new Set(progressRows.filter((p) => p.course_id === latestProgress.course_id && p.completed).map((p) => p.lesson_id));
    completedInCourse = completedIds.size;
    courseProgress = totalLessonsInCourse > 0 ? Math.round((completedInCourse / totalLessonsInCourse) * 100) : 0;
    nextLesson = allLessons.find((l: { id: string; title: string; slug: string; order_index: number }) => !completedIds.has(l.id)) ?? null;
  }

  // Recommended course if no active course
  let recommendedCourse: { title: string; slug: string } | null = null;
  if (!currentCourse) {
    const { data: rec } = await supabase.from("courses").select("title, slug").eq("is_published", true).eq("level", displayLevel).limit(1).single();
    recommendedCourse = rec ?? null;
  }

  const de = locale === "de";

  const missions = [
    { id: 1, text: de ? "8 neue Wörter lernen" : "Learn 8 new words" },
    { id: 2, text: de ? "1 Mini-Dialog abschließen" : "Complete 1 mini-dialogue" },
    { id: 3, text: de ? "5 Sätze mit dem KI-Trainer üben" : "Practice 5 sentences with AI" },
    { id: 4, text: de ? "1 Quiz-Checkpoint bestehen" : "Pass 1 quiz checkpoint" },
  ];

  const levelJourney = ["A1", "A2", "B1", "B2", "C1"] as const;
  const levelIndex = levelJourney.findIndex((l) => l === displayLevel);

  const card = "bg-[#0A1E35]/70 backdrop-blur-sm border border-white/8 rounded-2xl p-6";

  return (
    <AppLayout locale={locale} userName={userName} userLevel={displayLevel}>
      <div className="px-5 lg:px-8 py-6 lg:py-8 space-y-6 max-w-5xl w-full mx-auto">

        {/* ── Welcome banner ── */}
        <div className="relative overflow-hidden rounded-2xl border border-[#E0B873]/20 bg-gradient-to-br from-[#0E2845] via-[#0A1E35] to-[#071424]">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_rgba(224,184,115,0.12)_0%,_transparent_60%)]" />
          <div className="relative px-6 py-6 flex items-start justify-between gap-4 flex-wrap">
            <div>
              <p className="text-xs font-semibold text-[#E0B873]/70 uppercase tracking-[0.2em] mb-1.5">
                {new Date().toLocaleDateString(de ? "de-DE" : "en-GB", { weekday: "long", day: "numeric", month: "long" })}
              </p>
              <h1 className="text-2xl lg:text-3xl font-serif font-bold text-white leading-tight">
                {de ? `Willkommen zurück, ${userName.split(" ")[0]}` : `Welcome back, ${userName.split(" ")[0]}`}
              </h1>
              <p className="text-sm text-white/45 mt-1.5">
                {de ? "Jede Lektion bringt dich näher an dein Ziel." : "Every lesson brings you closer to your goal."}
              </p>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-center bg-[#E0B873]/8 border border-[#E0B873]/20 rounded-xl px-4 py-3">
                <Flame className="h-5 w-5 text-[#E0B873] mx-auto mb-1" />
                <p className="text-xl font-bold text-[#E0B873] leading-none">{completedLessons}</p>
                <p className="text-[9px] text-white/40 uppercase tracking-wider mt-0.5">{de ? "Lektionen" : "Lessons"}</p>
              </div>
              <div className="text-center bg-[#E0B873]/8 border border-[#E0B873]/20 rounded-xl px-4 py-3">
                <Trophy className="h-5 w-5 text-[#E0B873] mx-auto mb-1" />
                <p className="text-xl font-bold text-[#E0B873] leading-none">{displayLevel}</p>
                <p className="text-[9px] text-white/40 uppercase tracking-wider mt-0.5">{de ? "Niveau" : "Level"}</p>
              </div>
            </div>
          </div>
        </div>

        {/* ── Main 2-column grid ── */}
        <div className="grid lg:grid-cols-2 gap-5">

          {/* ── Continue Learning ── */}
          <div className={card}>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="h-6 w-6 rounded-md bg-[#E0B873]/15 flex items-center justify-center">
                  <Play className="h-3.5 w-3.5 text-[#E0B873] fill-current" />
                </div>
                <h2 className="text-sm font-semibold text-white">{de ? "Weiterlernen" : "Continue Learning"}</h2>
              </div>
              <Link href={`/${locale}/courses`} className="text-xs text-[#E0B873]/70 hover:text-[#E0B873] transition-colors flex items-center gap-1">
                {de ? "Alle" : "All"} <ChevronRight className="h-3 w-3" />
              </Link>
            </div>

            {currentCourse && nextLesson ? (
              <div className="space-y-4">
                <div className="p-4 rounded-xl bg-white/3 border border-white/6">
                  <p className="text-[10px] font-semibold text-[#E0B873]/70 uppercase tracking-wider mb-1">
                    {de ? "Aktueller Kurs" : "Current Course"}
                  </p>
                  <p className="text-sm font-semibold text-white mb-0.5">{currentCourse.title}</p>
                  <p className="text-xs text-white/35">{completedInCourse}/{totalLessonsInCourse} {de ? "abgeschlossen" : "completed"}</p>
                  <div className="mt-3 h-1.5 bg-white/5 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-[#E0B873] to-[#C99B50] rounded-full transition-all" style={{ width: `${courseProgress}%` }} />
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 rounded-xl bg-white/3 border border-white/6">
                  <div className="h-9 w-9 rounded-lg bg-[#E0B873]/12 border border-[#E0B873]/20 flex items-center justify-center flex-shrink-0">
                    <BookOpen className="h-4 w-4 text-[#E0B873]" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-[10px] text-white/35 uppercase tracking-wider">{de ? "Nächste Lektion" : "Next lesson"}</p>
                    <p className="text-sm font-medium text-white truncate">{nextLesson.title}</p>
                  </div>
                </div>
                <Link href={`/${locale}/lessons/${nextLesson.slug}`}
                  className="flex items-center justify-center gap-2 w-full py-3 rounded-xl bg-[#E0B873] text-[#071424] text-sm font-semibold hover:bg-[#C99B50] transition-colors">
                  <Play className="h-3.5 w-3.5 fill-current" />
                  {de ? "Lektion starten" : "Start Lesson"}
                </Link>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="p-4 rounded-xl bg-white/3 border border-white/6 text-center">
                  <BookMarked className="h-8 w-8 text-[#E0B873]/40 mx-auto mb-2" />
                  <p className="text-sm font-medium text-white mb-1">
                    {de ? "Noch kein Kurs aktiv" : "No active course yet"}
                  </p>
                  <p className="text-xs text-white/35">
                    {de ? "Starte einen Kurs, um deine Reise zu beginnen." : "Start a course to begin your journey."}
                  </p>
                </div>
                <Link href={`/${locale}/rooms`}
                  className="flex items-center justify-center gap-2 w-full py-3 rounded-xl bg-[#E0B873] text-[#071424] text-sm font-semibold hover:bg-[#C99B50] transition-colors">
                  {de ? "Lernräume erkunden" : "Explore Rooms"}
                </Link>
              </div>
            )}
          </div>

          {/* ── Daily Missions ── */}
          <div className={card}>
            <div className="flex items-center gap-2 mb-4">
              <div className="h-6 w-6 rounded-md bg-[#E0B873]/15 flex items-center justify-center">
                <Zap className="h-3.5 w-3.5 text-[#E0B873]" />
              </div>
              <h2 className="text-sm font-semibold text-white">{de ? "Tägliche Mission" : "Daily Mission"}</h2>
            </div>
            <p className="text-xs text-white/35 mb-4">
              {de ? "Erledige alle Aufgaben, um deinen Streak zu erhalten." : "Complete all tasks to maintain your streak."}
            </p>
            <div className="space-y-2.5">
              {missions.map((m) => (
                <div key={m.id} className="flex items-center gap-3 p-3 rounded-xl bg-white/3 border border-white/5">
                  <Circle className="h-4 w-4 text-white/20 flex-shrink-0" />
                  <span className="text-sm text-white/70">{m.text}</span>
                </div>
              ))}
            </div>
            <div className="mt-4 pt-4 border-t border-white/5 flex items-center justify-between">
              <p className="text-xs text-white/30">{de ? "0 von 4 erledigt" : "0 of 4 completed"}</p>
              <div className="flex gap-1">
                {[0, 1, 2, 3].map((i) => (
                  <div key={i} className="h-1.5 w-6 rounded-full bg-white/10" />
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* ── Level Journey ── */}
        <div className={card}>
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-[#E0B873]" />
              <h2 className="text-sm font-semibold text-white">{de ? "Dein Lernweg" : "Your Learning Journey"}</h2>
            </div>
            <Link href={`/${locale}/levels`} className="text-xs text-[#E0B873]/70 hover:text-[#E0B873] transition-colors">
              {de ? "Details →" : "Details →"}
            </Link>
          </div>
          <div className="flex items-center gap-2">
            {levelJourney.map((lvl, i) => {
              const isCurrent = lvl === displayLevel;
              const isCompleted = i < levelIndex;
              const isLocked = i > levelIndex;
              return (
                <div key={lvl} className="flex-1 flex flex-col items-center gap-2">
                  <div className={`h-9 w-9 rounded-full flex items-center justify-center text-xs font-bold border-2 transition-all ${
                    isCurrent ? "bg-[#E0B873] border-[#E0B873] text-[#071424] shadow-lg shadow-[#E0B873]/20" :
                    isCompleted ? "bg-[#E0B873]/20 border-[#E0B873]/40 text-[#E0B873]" :
                    "bg-white/3 border-white/10 text-white/25"
                  }`}>
                    {isCompleted ? <CheckCircle2 className="h-4 w-4" /> : lvl}
                  </div>
                  <span className={`text-[10px] font-medium ${isCurrent ? "text-[#E0B873]" : isLocked ? "text-white/20" : "text-white/50"}`}>
                    {lvl}
                  </span>
                  {i < levelJourney.length - 1 && (
                    <div className="absolute" />
                  )}
                </div>
              );
            })}
          </div>
          {/* connector lines */}
          <div className="flex items-center mt-1 px-4">
            {levelJourney.slice(0, -1).map((_, i) => (
              <div key={i} className={`flex-1 h-px mx-1 ${i < levelIndex ? "bg-[#E0B873]/30" : "bg-white/8"}`} />
            ))}
          </div>
        </div>

        {/* ── Placement + Quick actions ── */}
        <div className="grid lg:grid-cols-2 gap-5">
          {/* Placement test */}
          <div className={card}>
            <div className="flex items-center gap-2 mb-4">
              <FlaskConical className="h-4 w-4 text-[#E0B873]" />
              <h2 className="text-sm font-semibold text-white">{de ? "Einstufungstest" : "Placement Test"}</h2>
            </div>
            {latestPlacement ? (
              <div className="space-y-3">
                <div className="flex items-center gap-5 p-4 rounded-xl bg-white/3 border border-white/6">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-[#E0B873]">{latestPlacement.score}/10</p>
                    <p className="text-[10px] text-white/35 uppercase tracking-wider">{de ? "Punkte" : "Score"}</p>
                  </div>
                  <div className="w-px h-10 bg-white/10" />
                  <div className="text-center">
                    <p className="text-2xl font-bold text-white">{latestPlacement.level_result}</p>
                    <p className="text-[10px] text-white/35 uppercase tracking-wider">{de ? "Niveau" : "Level"}</p>
                  </div>
                </div>
                <Link href={`/${locale}/placement-test`} className="text-xs text-[#E0B873] hover:underline">
                  {de ? "Test wiederholen →" : "Retake test →"}
                </Link>
              </div>
            ) : (
              <div className="space-y-4">
                <p className="text-xs text-white/40">{de ? "Noch nicht absolviert." : "Not taken yet."}</p>
                <Link href={`/${locale}/placement-test`}
                  className="flex items-center justify-center gap-2 w-full py-2.5 rounded-xl bg-[#E0B873]/10 border border-[#E0B873]/20 text-[#E0B873] text-sm font-medium hover:bg-[#E0B873]/20 transition-colors">
                  <FlaskConical className="h-4 w-4" />
                  {de ? "Jetzt starten" : "Start now"}
                </Link>
              </div>
            )}
          </div>

          {/* Quick actions */}
          <div className={card}>
            <div className="flex items-center gap-2 mb-4">
              <MessageSquare className="h-4 w-4 text-[#E0B873]" />
              <h2 className="text-sm font-semibold text-white">{de ? "Schnellzugriff" : "Quick Access"}</h2>
            </div>
            <div className="grid grid-cols-2 gap-2.5">
              {[
                { href: `/${locale}/ai-trainer`, icon: MessageSquare, label: de ? "KI-Trainer" : "AI Trainer" },
                { href: `/${locale}/rooms`, icon: BookMarked, label: de ? "Räume" : "Rooms" },
                { href: `/${locale}/placement-test`, icon: FlaskConical, label: de ? "Quiz" : "Quiz" },
                { href: `/${locale}/levels`, icon: TrendingUp, label: de ? "Niveaus" : "Levels" },
              ].map(({ href, icon: Icon, label: lbl }) => (
                <Link key={href} href={href}
                  className="flex flex-col items-center gap-2 p-3.5 rounded-xl bg-white/3 border border-white/6 hover:border-[#E0B873]/25 hover:bg-[#E0B873]/5 transition-all group text-center">
                  <Icon className="h-5 w-5 text-[#E0B873]/60 group-hover:text-[#E0B873] transition-colors" />
                  <span className="text-xs font-medium text-white/55 group-hover:text-white/80 transition-colors">{lbl}</span>
                </Link>
              ))}
            </div>
          </div>
        </div>

      </div>
    </AppLayout>
  );
}
